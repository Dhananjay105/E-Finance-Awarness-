var firebaseConfig = {
 apiKey: "AIzaSyBEltzTjF1XwkoEWxBwn8gkPuSRdZzay6g",
  authDomain: "my-sample-a2537.firebaseapp.com",
  databaseURL: "https://my-sample-a2537-default-rtdb.firebaseio.com",
  projectId: "my-sample-a2537",
  storageBucket: "my-sample-a2537.appspot.com",
  messagingSenderId: "97637547734"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();


