var firebaseConfig = {
 apiKey: "AIzaSyD8EKiFt-lo7zp0ENfgZLTdHIpy9YwpNQ0",
  authDomain: "projectfa-7fea2.firebaseapp.com",
  databaseURL: "https://projectfa-7fea2-default-rtdb.firebaseio.com",
  projectId: "projectfa-7fea2",
  storageBucket: "projectfa-7fea2.appspot.com",
  messagingSenderId: "373417337003"	
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();



