// Initialize Firebase
var config = {
   apiKey: "AIzaSyD8EKiFt-lo7zp0ENfgZLTdHIpy9YwpNQ0",
  authDomain: "projectfa-7fea2.firebaseapp.com",
  databaseURL: "https://projectfa-7fea2-default-rtdb.firebaseio.com",
  projectId: "projectfa-7fea2",
  storageBucket: "projectfa-7fea2.appspot.com",
  messagingSenderId: "373417337003"
};

firebase.initializeApp(config);

const dbRef = firebase.database().ref();

const usersRef = dbRef.child('contact');
const userListUI = document.getElementById("userList");

usersRef.on("child_added", snap => {
	let user = snap.val();

	let $li = document.createElement("li");
	$li.innerHTML = user.company;
	
	$li.setAttribute("child-key", snap.key);
	$li.addEventListener("click", userClicked)
	userListUI.append($li);

});

function userClicked(e) {

	var userID = e.target.getAttribute("child-key");

	const userRef = dbRef.child('contact/' + userID);
	const userDetailUI = document.getElementById("userDetail");

	userDetailUI.innerHTML = ""

	userRef.on("child_added", snap => {

		var $p = document.createElement("p");
		$p.innerHTML = snap.key  + " - " +  snap.val()
		userDetailUI.append($p);
	});

}


