// Initialize Firebase
var config = {
  apiKey: "AIzaSyBpg1igg8gQT9VmV5PlyO_E_UHeMJmhJwU",
  authDomain: "farming-f35fb.firebaseapp.com",
  databaseURL: "https://farming-f35fb-default-rtdb.firebaseio.com",
  projectId: "farming-f35fb",
  storageBucket: "farming-f35fb.appspot.com",
  messagingSenderId: "1014735139241"
};

firebase.initializeApp(config);

const dbRef = firebase.database().ref();

const usersRef = dbRef.child('messages');
const userListUI = document.getElementById("userList");

usersRef.on("child_added", snap => {
	let user = snap.val();

	let $li = document.createElement("li");
	$li.innerHTML = user.company;
	
	$li.setAttribute("child-key", snap.key);
	$li.addEventListener("click", userClicked)
	userListUI.append($li);

});

function userClicked(e) {

	var userID = e.target.getAttribute("child-key");

	const userRef = dbRef.child('messages/' + userID);
	const userDetailUI = document.getElementById("userDetail");

	userDetailUI.innerHTML = ""

	userRef.on("child_added", snap => {

		var $p = document.createElement("p");
		$p.innerHTML = snap.key  + " - " +  snap.val()
		userDetailUI.append($p);
	});

}


