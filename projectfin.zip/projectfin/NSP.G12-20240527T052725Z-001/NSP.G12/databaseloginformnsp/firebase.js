var firebaseConfig = {
 apiKey: "AIzaSyCDrOwqVxiOFnOYa-ea6_FARYTSJWZe5pA",
  authDomain: "sample-97309.firebaseapp.com",
  databaseURL: "https://sample-97309-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "sample-97309",
  storageBucket: "sample-97309.appspot.com",
  messagingSenderId: "821119364408"
   
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();





